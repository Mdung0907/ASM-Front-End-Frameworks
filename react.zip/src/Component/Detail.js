import { useEffect, useState } from "react";
import { Col, Row } from "react-bootstrap";
import { callAPI } from "../Component/HomeMain/API";
import { useParams } from "react-router-dom";
const PostDetail = (props) => {
  const [post, setPost] = useState(null);
  const [loading, setLoading] = useState(true);
  const { id } = useParams();

  useEffect(() => {
    fetchDetail();
  }, []);

  const fetchDetail = async () => {
    console.log("Fetching detail");
    const data = await callAPI(`/mdungapi/blogs/${id}`, "GET");
    if (data) {
      console.log(data);
      setPost(data);
      setLoading(false);
    }
  };

  if (loading) {
    <Row>
      <h1>loading</h1>
    </Row>;
  }
  if (post) {
    return (
      <div className="img-wrapper">
        <img
          src={`${post.avatar || "https://via.placeholder.com/150"} `}
          alt=""
        />
        <div>
          <p style={{ fontWeight: "bold", marginBottom: 5 }}>{post.name}</p>
          <p>{post.desciption}
            {post.description}
          </p>
        </div>
      </div>
    );
  }
};
export default PostDetail;