
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "./Layout";
import Blogs from "./Blogs";
import Contact from "./Contact";
import NoPage from "./NoPage";
import App from './HomeMain/App'
import FormRegister from "./Register";
import FormLogin from "./Login";
import PostDetail from "./Detail";


export default function TestRouter() {
  
    return (
      <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={< App/>} />
          <Route path="register" element={<FormRegister />} />
          <Route path="login" element={<FormLogin />} />
          <Route path="/detail/:id" element={<PostDetail />} />
          <Route path="*" element={<NoPage />} />
        </Route>
      </Routes>
    </BrowserRouter>
    );
  }