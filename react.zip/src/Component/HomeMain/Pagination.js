import React from 'react';
import { useState, useEffect } from "react";
import ReactPaginate from 'react-paginate';
const Pagination = (props) => {
    const totalPages = props.response.totalPages - 1;
    const data = props.response.data;
    const pages = [];
    const pageNumberLimit = 5;
    const [passengersData, setData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [currentPage, setCurrentPage] = useState(1);
    const [maxPageLimit, setMaxPageLimit] = useState(5);
    const [minPageLimit, setMinPageLimit] = useState(0);

    for (let i = 1; i <= totalPages; i++) {
        pages.push(i);
    }
    const pageNumbers = pages.map(page => {
        if (page <= maxPageLimit && page > minPageLimit) {
            return (
                <li key={page} id={page} onClick={handlePageClick}
                    className={currentPage === page ? 'active' : null}>
                    {page}
                </li>
            );
        } else {
            return null;
        }
    }

    );

    let pageIncrementEllipses = null;
    if (pages.length > maxPageLimit) {
        pageIncrementEllipses = <li onClick={handleNextClick}>&hellip;</li>
    }
    let pageDecremenEllipses = null;
    if (minPageLimit >= 1) {
        pageDecremenEllipses = <li onClick={handlePrevClick}>&hellip;</li>
    }
    useEffect(() => {
        setLoading(true);
        fetch(`https://api.instantwebtools.net/v1/passenger?currentPage=${currentPage}&size=5`)
            .then((response) => response.json())
            .then((json) => { setData(json); setLoading(false); });

    }, [currentPage]);

    const renderData = (data) => {
        return (
            <ul>
                {data.map((d) =>
                    <li key={d.id}> The passenger having id {d.id}.slice({d.id}.length - 5) using {d.airline[0].name} airlines</li>)
                }
            </ul>
        )
    }

    return (
        <div className="main">
            <div className="mainData">
                {renderData(data)}
            </div>
            <ul className="pageNumbers">
                <li>
                    <button onClick={handlePrevClick} disabled={currentPage === pages[0]}>Prev</button>
                </li>
                {pageDecremenEllipses}
                {pageNumbers}
                {pageIncrementEllipses}
                <li>
                    <button onClick={handleNextClick} disabled={currentPage === pages[pages.length - 1]}>Next</button>
                </li>
            </ul>
        </div>
    );
    const handlePrevClick = () => {
        props.onPrevClick();
    }
    const handleNextClick = () => {
        props.onNextClick();
    }
    const handlePageClick = (e) => {
        props.onPageChange(Number(e.target.id));
    }
    const onPageChange = (pageNumber) => {
        setCurrentPage(pageNumber);
    }
    const onPrevClick = () => {
        if ((currentPage - 1) % pageNumberLimit === 0) {
            setMaxPageLimit(maxPageLimit - pageNumberLimit);
            setMinPageLimit(minPageLimit - pageNumberLimit);
        }
        setCurrentPage(prev => prev - 1);
    }

    const onNextClick = () => {
        if (currentPage + 1 > maxPageLimit) {
            setMaxPageLimit(maxPageLimit + pageNumberLimit);
            setMinPageLimit(minPageLimit + pageNumberLimit);
        }
        setCurrentPage(prev => prev + 1);
    }
    const paginationAttributes = {
        currentPage,
        maxPageLimit,
        minPageLimit,
        response: passengersData,
    };
    return (
        <div>
            <h2>Passenger List</h2>
            {!loading ? <Pagination {...paginationAttributes}
                onPrevClick={onPrevClick}
                onNextClick={onNextClick}
                onPageChange={onPageChange} />
                : <div> Loading... </div>
            }
        </div>
    )
}
export default Pagination;