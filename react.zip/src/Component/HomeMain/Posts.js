import ReactPaginate from "react-paginate";
import { useState } from "react";
import { BsFillBagXFill } from "react-icons/bs";
import { callAPI } from './API.js'
import { BsFillBookmarksFill } from "react-icons/bs";
import UpdatePost from "./UpdatePost.js";
import { Link } from "react-router-dom";

function Posts({ props, onReload,onReloadUpdate }) {
    const [isOpen, setisOpen] = useState(false);
    const [currentpage, setcurrentpage] = useState(1);
    const [id, setid] = useState(0);
    const currenPost = props.slice(currentpage * 9 - 9, currentpage * 9)

    const handlePageClick = (event) => {
        const newVal = event.selected;
        setcurrentpage(newVal + 1);
    };


    if (props.length == 0) {

        return <div className="loader"></div>
    }


    return (
        <div className="cuto">
            <div className="App">
                {currenPost && currenPost.map((post) => {
                    return (
                        <div className="img-wrapper" key={post.id} >
                            <img src={post?.avatar} />
                            <p className="name">
                            <Link to={`/detail/${post.id}`}> {post.name}</Link></p>
                            <BsFillBagXFill onClick={async () => {
                                const response = await callAPI(
                                    `/mdungapi/blogs/${post.id}`,
                                    "DELETE"
                                );
                                if (response) {
                                    alert("Delete successfully");
                                    onReload(post.id);
                                }else{
                                    alert('Delete fail')
                                }
                            }} style={{ cursor: 'pointer' }} color="red"></BsFillBagXFill>
                            <BsFillBookmarksFill
                                onClick={
                                    () => {
                                        setid(post.id)
                                        setisOpen(!isOpen)
                                    }
                                }
                            >
                            </BsFillBookmarksFill>
                            <UpdatePost isShow={isOpen}
                                handleClose={() => setisOpen(false)} 
                                propid={id}
                                onReload={onReloadUpdate}
                            
                                />
                        </div>
                    );
                })}
            </div>
            <div className="pagination">
                <ReactPaginate
                    breakLabel="..."
                    nextLabel="next >"
                    onPageChange={handlePageClick}
                    pageRangeDisplayed={5}
                    pageCount={Math.ceil(props.length / 9)}
                    previousLabel="< previous"
                    renderOnZeroPageCount={null}
                    breakClassName={"page-item"}
                    breakLinkClassName={"page-link"}
                    containerClassName={"pagination"}
                    pageClassName={"page-item"}
                    pageLinkClassName={"page-link"}
                    previousClassName={"page-item"}
                    previousLinkClassName={"page-link"}
                    nextClassName={"page-item"}
                    nextLinkClassName={"page-link"}
                    activeClassName={"active"}
                />
            </div>
        </div>
    )

}
export default Posts;