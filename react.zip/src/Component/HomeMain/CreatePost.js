import Button from 'react-bootstrap/Button';
import React, { useState } from 'react';
import Modal from 'react-bootstrap/Modal';
import 'bootstrap/dist/css/bootstrap.min.css';
import Form from 'react-bootstrap/Form';
import { callAPI } from './API.js'
import axios from 'axios';

const CreatePost = ({ isShow, handleClose, Reload }) => {
    const [post, setpost] = useState({});
    const [selectedFile, setSelectedFile] = React.useState(null);
    const OnchangeInput = (event) => {
        setpost({ ...post, [event.target.name]: event.target.value });
    }
    // const handleFileSelect = (event) => {
    //     setpost(event.target.files[0])
    // }
    const onHandleSubmit = async () => {
        const name = document.getElementById('idusername').value
        const des = document.getElementById('iddescription').value
        if (name == '') {
            alert('Name is empty')
        }else if(des==''){
            alert('Description is empty')
        } else {
            const data = await callAPI(`/mdungapi/blogs?`, "POST", post);
            if (data) {
                alert("Create succesfully")
                handleClose()
                Reload()
            } else {
                alert('Create fail')
            }
        }

    }

    return (
        <>
            <Modal show={isShow} onHide={handleClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Create Post</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form>
                        <Form.Group className="mb-3" controlId="idusername">
                            <Form.Label>Name</Form.Label>
                            <Form.Control onChange={OnchangeInput} name="name" type="text" placeholder="name" />
                        </Form.Group>

                        <Form.Group className="mb-3" controlId="idavatar">
                            <Form.Label>Avatar</Form.Label>
                            <Form.Control type="text" onChange={OnchangeInput} name="avatar" placeholder="avatar" />
                        </Form.Group>

                        <Form.Group className="mb-3" controlId="iddescription">
                            <Form.Label>Descripton</Form.Label>
                            <Form.Control onChange={OnchangeInput} name="description" as="textarea" placeholder="descripton" />
                        </Form.Group>
                    </Form>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleClose}>
                        Close
                    </Button>
                    <Button variant="primary" onClick={onHandleSubmit}>
                        Save Changes
                    </Button>
                </Modal.Footer>
            </Modal>
        </>
    );
}

export default CreatePost;