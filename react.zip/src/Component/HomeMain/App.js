// import logo from './logo.svg';
import '../../App.css';
import Posts from './Posts.js'
import SearchBar from './SearchPosts.js'
import { useEffect, useRef, useState } from "react";
import Button from 'react-bootstrap/Button';
import { callAPI } from './API.js'
import CreatePost from './CreatePost';


function App() {
  const [data, setdata] = useState([])
  const [isLoading, setIsLoading] = useState(false);
  const [isOpen, setisOpen] = useState(false);


  const FectPost = async () => {
    try {
      const response = await callAPI(`/mdungapi/blogs?`, "GET");
      setdata(response)
      setIsLoading(false)
    } catch (error) {
      console.error(error);
    }
  }

  const log = useRef(true)
  useEffect(() => {
    if (log.current) {
      log.current = false
      FectPost()
    }
  }, []);

  const SortASC = async () => {
    try {
      const response = await callAPI(`/mdungapi/blogs?sortBy=createdAt&order=asc`, "GET");
      setdata(response)
      setIsLoading(false)
    } catch (error) {
      console.error(error);
    }
  }

  const SortDESC = async () => {
    try {
      const response = await callAPI(`/mdungapi/blogs?sortBy=createdAt&order=desc`, "GET");
      setdata(response)
      setIsLoading(false)
    } catch (error) {
      console.error(error);
    }
  }
  const handleReload = (id) => {
    const updatePost = data.filter((post) => post.id !== id);
    setdata(updatePost);
  };
  const handleReloadUpdate = () => {
    FectPost()
  };

  return (<>

    <Posts
      props={data}
      onReload={handleReload}
      onReloadUpdate={handleReloadUpdate }/>

    <SearchBar
      placeholder={'Search...'}
      data={data}
    />
    <div className="d-grid gap-2">
      <Button variant="primary" size="lg" onClick={SortDESC}>
        Descending order
      </Button>
      <Button variant="secondary" size="lg" onClick={SortASC}>
        Ascending order
      </Button>
      <Button variant="primary" onClick={() => setisOpen(!isOpen)}>
        CreatePost
      </Button>
    </div>
    <CreatePost isShow={isOpen}
      handleClose={() => setisOpen(false)} 
      Reload={FectPost}
      />
  </>)

}
export default App;

