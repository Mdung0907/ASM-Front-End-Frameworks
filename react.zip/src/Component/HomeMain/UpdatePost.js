import Button from 'react-bootstrap/Button';
import React, { useState } from 'react';
import Modal from 'react-bootstrap/Modal';
import 'bootstrap/dist/css/bootstrap.min.css';
import Form from 'react-bootstrap/Form';
import { callAPI } from './API.js'


const UpdatePost = ({ isShow, handleClose, propid ,onReload}) => {
    const [post, setpost] = useState({});
    const OnchangeInput = (event) => {
        setpost({ ...post, [event.target.name]: event.target.value });
    }


    const onHandleSubmit = async () => {
        const data = await callAPI(`/mdungapi/blogs/${propid}`, "PUT", post);
        if (data) {
            alert("Update succesfully")
            handleClose();
            onReload()
        } else {
            alert('Update fail')
        }


    }


    return (
        <>
            <Modal show={isShow} onHide={handleClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Update Post</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form>
                        <Form.Group className="mb-3" controlId="formBasicEmail">
                            <Form.Label>Name</Form.Label>
                            <Form.Control onChange={OnchangeInput} name="name" type="text" placeholder="name" />
                        </Form.Group>

                        <Form.Group className="mb-3" controlId="formBasicPassword">
                            <Form.Label>Avatar</Form.Label>
                            <Form.Control onChange={OnchangeInput} name="avatar" type="text" placeholder="avatar" />
                        </Form.Group>

                        <Form.Group className="mb-3" controlId="formBasicPassword">
                            <Form.Label>Descripton</Form.Label>
                            <Form.Control onChange={OnchangeInput} name="description" as="textarea" placeholder="descripton" />
                        </Form.Group>
                    </Form>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleClose}>
                        Close
                    </Button>
                    <Button variant="primary" onClick={onHandleSubmit
                    }>
                        Save Changes
                    </Button>
                </Modal.Footer>
            </Modal>
        </>
    );
}

export default UpdatePost;